#!/usr/bin/env python3
# Rose Runner — local server launcher
# Double-click this file or run: python3 serve.py
import http.server, webbrowser, threading, os

PORT = 8080
os.chdir(os.path.dirname(os.path.abspath(__file__)))

class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

httpd = http.server.HTTPServer(('', PORT), Handler)
url = f'http://localhost:{PORT}/index.html'
print(f'\n🐱 Rose Runner corriendo en {url}')
print('Cierra esta ventana para parar el servidor.\n')
threading.Timer(1, lambda: webbrowser.open(url)).start()
httpd.serve_forever()
